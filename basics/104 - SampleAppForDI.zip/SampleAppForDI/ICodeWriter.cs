﻿public interface ICodeWriter
{
	string GetCode();
}
